The OSMF YouTube plug-in is built off of the YouTube API. As a result, any usage of this plug-in must be done with a full understanding and compliance with the YouTube Terms of Service.

The YouTube API Terms of Service can be found at: http://code.google.com/apis/youtube/terms.html